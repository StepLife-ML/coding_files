#! /bin/bash

killall -9  rqt_image_view
killall -9  python
killall -9  republish
killall -9  roslaunch
killall -9  gzserver
killall -9  gzclient

