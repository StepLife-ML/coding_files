#! /bin/bash

#Kill in LAPTOP
killall -9 ssh
killall -9 roslaunch
killall -9 rosout
killall -9 rosmaster
killall -9  gzserver
killall -9  gzclient

#source files
source /opt/ros/kinetic/setup.bash

source ~/catkin_ws/devel/setup.bash

echo "roscore start"

roscore &

sleep 5


roslaunch turtlebot3_gazebo turtlebot3_autorace.launch &


sleep 10



source ~/catkin_ws/devel/setup.bash
export TURTLEBOT3_MODEL=burger
roslaunch turtlebot3_gazebo turtlebot3_autorace_mission.launch &


sleep 5

source ~/catkin_ws/devel/setup.bash
export GAZEBO_MODE=true
export AUTO_IN_CALIB=action
roslaunch turtlebot3_autorace_camera turtlebot3_autorace_intrinsic_camera_calibration.launch &


sleep 10

source ~/catkin_ws/devel/setup.bash
export AUTO_EX_CALIB=action
export AUTO_DT_CALIB=action
export TURTLEBOT3_MODEL=burger
roslaunch turtlebot3_autorace_core turtlebot3_autorace_core.launch &



sleep 10

rqt_image_view &



sleep 5

rostopic pub -1 /core/decided_mode std_msgs/UInt8 "data: 2"





